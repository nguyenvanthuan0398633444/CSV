/*****�H���e�[�u���̍č쐬*****/
DROP TABLE t_manhour;
CREATE TABLE t_manhour (
	year smallint(0) NOT NULL,
	month smallint(0) NOT NULL,
	user_no varchar(9) NOT NULL,
	group_code varchar(10) NULL,
	site_code varchar(8) NULL,
	theme_no varchar(12) NOT NULL,
	work_contents_class varchar(2) NOT NULL,
	work_contents_code varchar(2) NOT NULL,
	work_contents_detail varchar(2) NOT NULL,
	pin_flg boolean(0) default False NULL,
	total float(0) default 0 NULL,
	day1 float(0) default 0 NULL,
	day2 float(0) default 0 NULL,
	day3 float(0) default 0 NULL,
	day4 float(0) default 0 NULL,
	day5 float(0) default 0 NULL,
	day6 float(0) default 0 NULL,
	day7 float(0) default 0 NULL,
	day8 float(0) default 0 NULL,
	day9 float(0) default 0 NULL,
	day10 float(0) default 0 NULL,
	day11 float(0) default 0 NULL,
	day12 float(0) default 0 NULL,
	day13 float(0) default 0 NULL,
	day14 float(0) default 0 NULL,
	day15 float(0) default 0 NULL,
	day16 float(0) default 0 NULL,
	day17 float(0) default 0 NULL,
	day18 float(0) default 0 NULL,
	day19 float(0) default 0 NULL,
	day20 float(0) default 0 NULL,
	day21 float(0) default 0 NULL,
	day22 float(0) default 0 NULL,
	day23 float(0) default 0 NULL,
	day24 float(0) default 0 NULL,
	day25 float(0) default 0 NULL,
	day26 float(0) default 0 NULL,
	day27 float(0) default 0 NULL,
	day28 float(0) default 0 NULL,
	day29 float(0) default 0 NULL,
	day30 float(0) default 0 NULL,
	day31 float(0) default 0 NULL,
	fix_date varchar(8) default 0 NULL,
CONSTRAINT PK_t_manhour PRIMARY KEY(year,month,user_no,theme_no,work_contents_class,work_contents_code,work_contents_detail))
;

COMMENT ON TABLE t_manhour IS '�H���e�[�u��';

COMMENT ON COLUMN t_manhour.year IS '�N';

COMMENT ON COLUMN t_manhour.month IS '��';

COMMENT ON COLUMN t_manhour.user_no IS '���[�U�[NO';

COMMENT ON COLUMN t_manhour.group_code IS '�����R�[�h';

COMMENT ON COLUMN t_manhour.site_code IS '�T�C�g�R�[�h';

COMMENT ON COLUMN t_manhour.theme_no IS '�e�[�}NO';

COMMENT ON COLUMN t_manhour.work_contents_class IS '��Ɠ��e�敪';

COMMENT ON COLUMN t_manhour.work_contents_code IS '��Ɠ��e�R�[�h';

COMMENT ON COLUMN t_manhour.work_contents_detail IS '��Ɠ��e�ڍ�';

COMMENT ON COLUMN t_manhour.pin_flg IS '�s���~�߃t���O';

COMMENT ON COLUMN t_manhour.total IS '���v';

COMMENT ON COLUMN t_manhour.day1 IS '1��';

COMMENT ON COLUMN t_manhour.day2 IS '2��';

COMMENT ON COLUMN t_manhour.day3 IS '3��';

COMMENT ON COLUMN t_manhour.day4 IS '4��';

COMMENT ON COLUMN t_manhour.day5 IS '5��';

COMMENT ON COLUMN t_manhour.day6 IS '6��';

COMMENT ON COLUMN t_manhour.day7 IS '7��';

COMMENT ON COLUMN t_manhour.day8 IS '8��';

COMMENT ON COLUMN t_manhour.day9 IS '9��';

COMMENT ON COLUMN t_manhour.day10 IS '10��';

COMMENT ON COLUMN t_manhour.day11 IS '11��';

COMMENT ON COLUMN t_manhour.day12 IS '12��';

COMMENT ON COLUMN t_manhour.day13 IS '13��';

COMMENT ON COLUMN t_manhour.day14 IS '14��';

COMMENT ON COLUMN t_manhour.day15 IS '15��';

COMMENT ON COLUMN t_manhour.day16 IS '16��';

COMMENT ON COLUMN t_manhour.day17 IS '17��';

COMMENT ON COLUMN t_manhour.day18 IS '18��';

COMMENT ON COLUMN t_manhour.day19 IS '19��';

COMMENT ON COLUMN t_manhour.day20 IS '20��';

COMMENT ON COLUMN t_manhour.day21 IS '21��';

COMMENT ON COLUMN t_manhour.day22 IS '22��';

COMMENT ON COLUMN t_manhour.day23 IS '23��';

COMMENT ON COLUMN t_manhour.day24 IS '24��';

COMMENT ON COLUMN t_manhour.day25 IS '25��';

COMMENT ON COLUMN t_manhour.day26 IS '26��';

COMMENT ON COLUMN t_manhour.day27 IS '27��';

COMMENT ON COLUMN t_manhour.day28 IS '28��';

COMMENT ON COLUMN t_manhour.day29 IS '29��';

COMMENT ON COLUMN t_manhour.day30 IS '30��';

COMMENT ON COLUMN t_manhour.day31 IS '31��';

COMMENT ON COLUMN t_manhour.fix_date IS '�m����t';


/*****�H���e�[�u���̃C���f�b�N�X�č쐬*****/
DROP INDEX IDX_t_manhour_1;
DROP INDEX IDX_t_manhour_2;
DROP INDEX IDX_t_manhour_3;





